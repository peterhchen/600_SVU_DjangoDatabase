from pymongo import MongoClient                #creating DB
democlient = MongoClient()
myclient = MongoClient('localhost',27017)
mydb = myclient["demo"]
mycoll=mydb["dbtable"]

for x in mycoll.find():   # find all the occurrences in collection.
  print('x:', x)
