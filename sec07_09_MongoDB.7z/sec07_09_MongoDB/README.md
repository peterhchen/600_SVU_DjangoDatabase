# mongoDB
system admin command operation
